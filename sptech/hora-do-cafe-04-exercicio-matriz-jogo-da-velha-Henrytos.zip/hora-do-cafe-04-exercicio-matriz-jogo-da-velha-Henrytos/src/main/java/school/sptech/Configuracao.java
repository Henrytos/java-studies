package school.sptech;

public class Configuracao {

  public static String BACKGROUND_COLOR = "#F3F3F3";
  public static String FOREGROUND_COLOR = "#141617";
  public static String PLAYER_1_COLOR = "#CB4648";
  public static String PLAYER_2_COLOR = "#A39FBF";
}
