package school.sptech;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

@DisplayName("Exercício 1 - Nome do exercício")
class MainTests {

  @Test
  @DisplayName("Cenário 1 - Descrição do cenário")
  void cenario1() {
    Assertions.assertTrue(true);
  }
}
