package school.sptech;

public interface Avaliavel {
    void avaliar(Integer nota);

    Double calcularMedia();

}
