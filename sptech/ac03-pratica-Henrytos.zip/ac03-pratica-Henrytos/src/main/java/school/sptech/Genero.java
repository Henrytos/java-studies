package school.sptech;

public enum Genero {
    ROCK,
    POP,
    MPB,
    FUNK,
    ELETRONICA,
    SERTANEJO;


}
